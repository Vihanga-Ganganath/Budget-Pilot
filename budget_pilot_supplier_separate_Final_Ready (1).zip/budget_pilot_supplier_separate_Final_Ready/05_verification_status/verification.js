
function toast(m){const t=document.getElementById('toast');t.textContent=m;t.style.display='block';setTimeout(()=>t.style.display='none',2200)}
document.querySelectorAll('.doc').forEach(b=>b.onclick=()=>toast(`${b.dataset.name}: action opened.`));
document.getElementById('updateAll').onclick=()=>{const p=document.querySelector('.pending');p.textContent='✓ VERIFIED';p.className='pill green';toast('All verification documents refreshed.')};
document.getElementById('addProduct').onclick=()=>location.href='../03_product_catalog/catalog.html#add';
document.getElementById('help').onclick=e=>{e.preventDefault();alert('Help Center opened.')};
document.getElementById('logout').onclick=e=>{e.preventDefault();localStorage.removeItem('bpSupplierLoggedIn');location.href='../01_supplier_login/login.html'};
